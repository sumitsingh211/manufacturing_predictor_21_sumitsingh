import os
import numpy as np
import joblib

# -------------------------------
# Load model and scaler
# -------------------------------
backend_folder = os.path.dirname(__file__)
model_path = os.path.join(backend_folder, "heart_model.pkl")
scaler_path = os.path.join(backend_folder, "scaler.pkl")

# Load the files safely
model = joblib.load(model_path)
scaler = joblib.load(scaler_path)

# -------------------------------
# Prediction function
# -------------------------------
def predict_heart_disease(features):
    # Convert input to numpy array
    input_data = np.array(features).reshape(1, -1)

    # Scale input
    input_scaled = scaler.transform(input_data)

    # Predict class
    prediction = model.predict(input_scaled)[0]

    # Try to get prediction probability
    try:
        proba = model.predict_proba(input_scaled)[0][1] * 100  # probability of class 1
    except:
        # If model doesn't support predict_proba
        proba = 90 if prediction == 1 else 10

    # Return both class and percentage
    return int(prediction), round(float(proba), 2)
