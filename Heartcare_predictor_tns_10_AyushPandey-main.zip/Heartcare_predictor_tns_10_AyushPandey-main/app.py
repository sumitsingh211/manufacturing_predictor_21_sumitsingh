import sys
import os
import streamlit as st

# -------------------------------
# Import backend
# -------------------------------
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.predict import predict_heart_disease

# -------------------------------
# Page Config
# -------------------------------
st.set_page_config(page_title="HeartCare Predictor ❤️", page_icon="❤️", layout="centered")

# -------------------------------
# Custom CSS for Light Theme & Styling
# -------------------------------
st.markdown("""
    <style>
    /* 🌈 Background Gradient */
    .stApp {
        background: linear-gradient(135deg, #f0f9ff, #e0f7fa, #f1f8e9);
        color: #333;
        font-family: "Poppins", sans-serif;
    }

    /* 🩵 Input boxes */
    .stNumberInput, .stSelectbox {
        background-color: #e3f2fd !important;
        border-radius: 10px !important;
        padding: 8px !important;
    }

    /* 🔹 Labels */
    label {
        color: #1a73e8 !important;
        font-weight: 600 !important;
    }

    /* ❤️ Title */
    h1 {
        text-align: center;
        color: #e63946;
        font-weight: 800;
    }

    /* 💙 Button style */
    div.stButton > button {
        background-color: #1a73e8 !important;
        color: white !important;
        border-radius: 10px !important;
        height: 50px !important;
        width: 220px !important;
        font-size: 18px !important;
        transition: all 0.3s ease;
    }

    div.stButton > button:hover {
        background-color: #0b56c2 !important;
        transform: scale(1.05);
    }

    /* 🧭 Result styling */
    .result-box {
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        font-size: 22px;
        font-weight: bold;
        box-shadow: 0px 3px 8px rgba(0,0,0,0.15);
        margin-top: 20px;
    }

    .high-risk {
        background-color: #ffebee;
        color: #d32f2f;
    }

    .low-risk {
        background-color: #e8f5e9;
        color: #2e7d32;
    }
    </style>
""", unsafe_allow_html=True)

# -------------------------------
# UI Section
# -------------------------------
st.markdown("<h1>❤️ HeartCare Predictor</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align:center;font-size:18px;color:#444;'>Enter your health details to assess your heart disease risk.</p>", unsafe_allow_html=True)
st.markdown("<hr>", unsafe_allow_html=True)

col1, col2 = st.columns(2)

with col1:
    age = st.number_input("Age", 20, 100)
    sex = st.selectbox("Sex", ["Male", "Female"])
    cp = st.number_input("Chest Pain Type (0–3)", 0, 3)
    trestbps = st.number_input("Resting Blood Pressure", 80, 200)
    chol = st.number_input("Cholesterol", 100, 400)
    fbs = st.selectbox("Fasting Blood Sugar >120 mg/dl", ["Yes", "No"])

with col2:
    restecg = st.number_input("Resting ECG (0–2)", 0, 2)
    thalach = st.number_input("Max Heart Rate", 70, 210)
    exang = st.selectbox("Exercise Induced Angina", ["Yes", "No"])
    oldpeak = st.number_input("ST Depression", 0.0, 6.0, step=0.1)
    slope = st.number_input("Slope (0–2)", 0, 2)
    ca = st.number_input("Major Vessels (0–4)", 0, 4)
    thal = st.number_input("Thal (0–3)", 0, 3)

# Convert dropdowns to numeric
sex_val = 1 if sex == "Male" else 0
fbs_val = 1 if fbs == "Yes" else 0
exang_val = 1 if exang == "Yes" else 0

# -------------------------------
# Predict Button
# -------------------------------
st.markdown("<br>", unsafe_allow_html=True)
if st.button("💓 Predict Risk"):
    features = [age, sex_val, cp, trestbps, chol, fbs_val, restecg,
                thalach, exang_val, oldpeak, slope, ca, thal]
    try:
        risk_class, risk_percent = predict_heart_disease(features)

        if risk_class == 1:
            st.markdown(
                f"<div class='result-box high-risk'>⚠️ High Risk of Heart Disease ({risk_percent}%)</div>",
                unsafe_allow_html=True
            )
        else:
            st.markdown(
                f"<div class='result-box low-risk'>✅ Low Risk of Heart Disease ({risk_percent}%)</div>",
                unsafe_allow_html=True
            )

        st.progress(int(risk_percent))
    except Exception as e:
        st.error(f"❌ Error during prediction: {e}")
